export interface RESTCountry {
  name: string;
  capital: string;
  region: string;
  subregion: string;
  population: number;

  flag: string;

  flags: Flags;

  alpha2Code: string;
  alpha3Code: string;

  languages: Language[];
}

export interface Flags {
  png: string;
  svg: string;
}

export interface Language {
  name: string;
}