import { Country } from "../interfaces/country.interface";
import { RESTCountry } from "../interfaces/rest-countries.interface";

export class CountryMapper {

  static mapRestCountryToCountry(restCountry: RESTCountry): Country {

    return {

      capital: restCountry.capital,

      cca2: restCountry.alpha2Code,

      flag: restCountry.flag,

      flagSvg: restCountry.flags.svg,

      name: restCountry.name,

      population: restCountry.population,

      region: restCountry.region,

      subRegion: restCountry.subregion,

    }

  }

  static mapRestCountryArrayToCountryArray(
    restCountries: RESTCountry[]
  ): Country[] {

    return restCountries.map(country =>
      this.mapRestCountryToCountry(country)
    );

  }

}